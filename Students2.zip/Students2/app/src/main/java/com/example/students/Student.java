package com.example.students;
import java.util.ArrayList;
import java.util.Arrays;

public class Student {
    private String name;
    private String groupNamber;

    public Student(String name, String groupNamber) {
        this.name = name;
        this.groupNamber = groupNamber;
    }

    public String getName() {
        return name;
    }

    public String getGroupNamber() {
        return groupNamber;
    }

    private final static ArrayList<Student> students = new ArrayList<Student>(
            Arrays.asList(
                    new Student("Іванов Роман", "301"),
                    new Student("Петров Федір", "301"),
                    new Student("Якубін Костя", "302"),
                    new Student("Максімов Руслан", "302"),
                    new Student("Смірнов Василь", "308"),
                    new Student("Потапова Марія", "309"),
                    new Student("Гонський Іван", "309"),
                    new Student("Васильєв Максим", "309")
            )
    );

    public static ArrayList<Student> getStudent(String groupNamber) {
        ArrayList<Student> stList = new ArrayList<>();
        for (Student s : students) {
            if (s.getGroupNamber().equals(groupNamber)) {
                stList.add(s);
            }
        }
        return stList;
    }
}
